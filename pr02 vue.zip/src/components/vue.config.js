module.exports = {
  devServer: {
    compress: true,
    disableHostCheck: true,
  },
};
